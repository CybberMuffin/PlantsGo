export interface Plant {
    id: number;
    name: string;
    description: string;
    pour: number;
}
