import { Injectable } from '@angular/core';
import {Plant} from "~/plant";
import {ObservableArray} from "tns-core-modules/data/observable-array";

const Sqlite = require("nativescript-sqlite");
const firebase = require("nativescript-plugin-firebase");
require( "nativescript-localstorage" );

@Injectable({
  providedIn: 'root'
})
export class PlantsService {
    private database: any;
    private _list;

  constructor() {
      /*(new Sqlite("plants.db")).then(db => {
          db.execSQL("CREATE TABLE IF NOT EXISTS `plants` (" +
	"`id`	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
	"`name`	TEXT, " +
	"`description`	TEXT, " +
	"`pour`	INTEGER);").then(id => {
              this.database = db;
              console.log("Could be success");
          }, error => {
              console.log("CREATE TABLE ERROR", error);
          });
      }, error => {
          console.log("OPEN DB ERROR", error);
      });*/
      this._list = new Array<Plant>(
          { id: 1, name: "Rose", description: "nice rose", pour: 1 },
          { id: 2, name:"Cactus", description: "dust", pour: 7 }
      );

      //this.addNew(3, "Tulip", "nice tulip", 2);
      //this._list.push({id: 3, name: "Tulip", description: "nice tulip", pour: 2});
      //this.setIt();
      /*this.fetch();
      this._list.push({ id: 1, name: "kek", description: "loles", pour: 4 })*/
  }

  public save(){
      let listString = JSON.stringify(this._list);
      localStorage.setItem('Plants', listString);
  }

  public get(){
      let listString = localStorage.getItem('Plants');
      this._list = JSON.parse(listString);
  }

  public addNew(id: number, name: string, description: string, pour: number){
      this.get();
      this._list.push({id: id, name: name, description: description, pour: pour});
      this.save();
  }

  public update(id: number, name: string, desc: string, pour: number){
      this.get();
      let objToUpdate = this._list.find((obj) => obj.id == id);
      objToUpdate.name = name == "" ? objToUpdate.name : name;
      objToUpdate.description = desc == "" ? objToUpdate.description : desc;
      objToUpdate.pour = pour < 0 ? objToUpdate.pour : pour;
      const bs = this._list.filter((obj) => obj.id != id);
      this._list = [...bs, objToUpdate];
      this.save();
  }

  public delete(id: number){
      this.get();
      const bs = this._list.filter((obj) => obj.id != id);
      this._list = [...bs];
      this.save();
  }

  setIt(){
      firebase.setValue(
          '/companies',
          {
              foo: 'bar',
              updateTs: firebase.ServerValue.TIMESTAMP
          }
      );

      firebase.push(
          '/users',
          {
              'first': 'Eddy',
              'last': 'Verbruggen',
              'birthYear': 1977,
              'isMale': true,
              'address': {
                  'street': 'foostreet',
                  'number': 123
              }
          }
      ).then(
          function (result) {
              console.log("created key: " + result.key);
          }
      );
  }

   /* public fetch() {
        this.database.all("SELECT * FROM `plants`").then(rows => {
            this._list = new ObservableArray([]);
            for(let row in rows) {
                this._list.push({
                    id: rows[row][0],
                    name: rows[row][1],
                    description: rows[row][2],
                    pour: rows[row][3]
                });
            }
        }, error => {
            console.log("SELECT ERROR", error);
        });
    }*/

    get list(): Plant[] {
        return this._list;
    }

    set list(value: Plant[]) {
        this._list = value;
    }
}
