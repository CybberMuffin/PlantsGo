"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var firebase = require("nativescript-plugin-firebase");
var FirebaseService = /** @class */ (function () {
    function FirebaseService() {
        this.path = '/plants';
        /*firebase.init();*/
        /*  firebase.setValue(
              '/plants',
              [
                  {id: 0, name: 'Rose', description: 'Very beautiful', pour: 1},
                  {id: 1, name: 'Cactus', description: 'Very needle', pour: 7},
                  {id: 2, name: 'Flower', description: 'Usual', pour: 2}
              ]
          );*/
    }
    FirebaseService.prototype.getAll = function () {
        var _this = this;
        firebase.getValue(this.path)
            .then(function (result) {
            _this.JsonFile = result.value;
            console.log(JSON.stringify(result));
            console.log(JSON.stringify(result.value));
            _this.arr = result.value;
            console.log(JSON.stringify(_this.JsonFile));
        })
            .catch(function (error) { return console.log("Error: " + error); });
        return this;
        //return JSON.parse(JSON.stringify(this.JsonFile));
    };
    /*public retArr(): Plant[] {
        let arra = new Array<Plant>();
        for (let i in this.arr) {
            arra.push({id: this.arr[i]["id"], name: this.arr[i]["name"],
                description: this.arr[i]["description"], pour: this.arr[i]["pour"]});
        }
        return arra;
    }*/
    FirebaseService.prototype.getArray = function () {
        var arr = JSON.parse(JSON.stringify(this.JsonFile));
        return arr;
    };
    FirebaseService.prototype.setValue = function (arrayOfObjects) {
        firebase.setValue(this.path, arrayOfObjects);
    };
    FirebaseService = __decorate([
        core_1.Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], FirebaseService);
    return FirebaseService;
}());
exports.FirebaseService = FirebaseService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlyZWJhc2Uuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImZpcmViYXNlLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBMkM7QUFDM0MsdURBQTBEO0FBTTFEO0lBS0U7UUFGUSxTQUFJLEdBQVcsU0FBUyxDQUFDO1FBRzdCLG9CQUFvQjtRQUN0Qjs7Ozs7OztjQU9NO0lBQ1IsQ0FBQztJQUVNLGdDQUFNLEdBQWI7UUFBQSxpQkFlQztRQWRHLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzthQUN2QixJQUFJLENBQUMsVUFBQSxNQUFNO1lBQ1IsS0FBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQzdCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUUxQyxLQUFJLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7WUFFeEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFBO1FBQzlDLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxVQUFBLEtBQUssSUFBSSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxFQUE5QixDQUE4QixDQUFDLENBQUM7UUFFcEQsTUFBTSxDQUFDLElBQUksQ0FBQztRQUNaLG1EQUFtRDtJQUN2RCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUVJLGtDQUFRLEdBQWY7UUFDSSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDcEQsTUFBTSxDQUFDLEdBQUcsQ0FBQztJQUNmLENBQUM7SUFFTyxrQ0FBUSxHQUFoQixVQUFpQixjQUE0QjtRQUN6QyxRQUFRLENBQUMsUUFBUSxDQUNiLElBQUksQ0FBQyxJQUFJLEVBQ1QsY0FBYyxDQUNqQixDQUFDO0lBQ04sQ0FBQztJQXJEVSxlQUFlO1FBSDNCLGlCQUFVLENBQUM7WUFDVixVQUFVLEVBQUUsTUFBTTtTQUNuQixDQUFDOztPQUNXLGVBQWUsQ0FzRDNCO0lBQUQsc0JBQUM7Q0FBQSxBQXRERCxJQXNEQztBQXREWSwwQ0FBZSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCBmaXJlYmFzZSA9IHJlcXVpcmUoXCJuYXRpdmVzY3JpcHQtcGx1Z2luLWZpcmViYXNlXCIpO1xuaW1wb3J0IHtQbGFudH0gZnJvbSBcIn4vcGxhbnRcIjtcblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCdcbn0pXG5leHBvcnQgY2xhc3MgRmlyZWJhc2VTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBKc29uRmlsZTogSlNPTjtcbiAgcHJpdmF0ZSBhcnI7XG4gIHByaXZhdGUgcGF0aDogc3RyaW5nID0gJy9wbGFudHMnO1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgICAgLypmaXJlYmFzZS5pbml0KCk7Ki9cbiAgICAvKiAgZmlyZWJhc2Uuc2V0VmFsdWUoXG4gICAgICAgICAgJy9wbGFudHMnLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgICAge2lkOiAwLCBuYW1lOiAnUm9zZScsIGRlc2NyaXB0aW9uOiAnVmVyeSBiZWF1dGlmdWwnLCBwb3VyOiAxfSxcbiAgICAgICAgICAgICAge2lkOiAxLCBuYW1lOiAnQ2FjdHVzJywgZGVzY3JpcHRpb246ICdWZXJ5IG5lZWRsZScsIHBvdXI6IDd9LFxuICAgICAgICAgICAgICB7aWQ6IDIsIG5hbWU6ICdGbG93ZXInLCBkZXNjcmlwdGlvbjogJ1VzdWFsJywgcG91cjogMn1cbiAgICAgICAgICBdXG4gICAgICApOyovXG4gIH1cblxuICBwdWJsaWMgZ2V0QWxsKCkge1xuICAgICAgZmlyZWJhc2UuZ2V0VmFsdWUodGhpcy5wYXRoKVxuICAgICAgICAgIC50aGVuKHJlc3VsdCA9PiB7XG4gICAgICAgICAgICAgIHRoaXMuSnNvbkZpbGUgPSByZXN1bHQudmFsdWU7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHJlc3VsdCkpO1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShyZXN1bHQudmFsdWUpKTtcblxuICAgICAgICAgICAgICB0aGlzLmFyciA9IHJlc3VsdC52YWx1ZTtcblxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeSh0aGlzLkpzb25GaWxlKSlcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5jYXRjaChlcnJvciA9PiBjb25zb2xlLmxvZyhcIkVycm9yOiBcIiArIGVycm9yKSk7XG5cbiAgICAgIHJldHVybiB0aGlzO1xuICAgICAgLy9yZXR1cm4gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzLkpzb25GaWxlKSk7XG4gIH1cblxuICAvKnB1YmxpYyByZXRBcnIoKTogUGxhbnRbXSB7XG4gICAgICBsZXQgYXJyYSA9IG5ldyBBcnJheTxQbGFudD4oKTtcbiAgICAgIGZvciAobGV0IGkgaW4gdGhpcy5hcnIpIHtcbiAgICAgICAgICBhcnJhLnB1c2goe2lkOiB0aGlzLmFycltpXVtcImlkXCJdLCBuYW1lOiB0aGlzLmFycltpXVtcIm5hbWVcIl0sXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiB0aGlzLmFycltpXVtcImRlc2NyaXB0aW9uXCJdLCBwb3VyOiB0aGlzLmFycltpXVtcInBvdXJcIl19KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBhcnJhO1xuICB9Ki9cblxuICBwdWJsaWMgZ2V0QXJyYXkoKSB7XG4gICAgICBsZXQgYXJyID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzLkpzb25GaWxlKSk7XG4gICAgICByZXR1cm4gYXJyO1xuICB9XG5cbiAgcHJpdmF0ZSBzZXRWYWx1ZShhcnJheU9mT2JqZWN0czogQXJyYXk8UGxhbnQ+KSB7XG4gICAgICBmaXJlYmFzZS5zZXRWYWx1ZShcbiAgICAgICAgICB0aGlzLnBhdGgsXG4gICAgICAgICAgYXJyYXlPZk9iamVjdHNcbiAgICAgICk7XG4gIH1cbn1cbiJdfQ==