import { Injectable } from '@angular/core';
import firebase = require("nativescript-plugin-firebase");
import {Plant} from "~/plant";

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  private JsonFile: JSON;
  private arr;
  private path: string = '/plants';

  constructor() {
      /*firebase.init();*/
    /*  firebase.setValue(
          '/plants',
          [
              {id: 0, name: 'Rose', description: 'Very beautiful', pour: 1},
              {id: 1, name: 'Cactus', description: 'Very needle', pour: 7},
              {id: 2, name: 'Flower', description: 'Usual', pour: 2}
          ]
      );*/
  }

  public getAll() {
      firebase.getValue(this.path)
          .then(result => {
              this.JsonFile = result.value;
              console.log(JSON.stringify(result));
              console.log(JSON.stringify(result.value));

              this.arr = result.value;

              console.log(JSON.stringify(this.JsonFile))
          })
          .catch(error => console.log("Error: " + error));

      return this;
      //return JSON.parse(JSON.stringify(this.JsonFile));
  }

  /*public retArr(): Plant[] {
      let arra = new Array<Plant>();
      for (let i in this.arr) {
          arra.push({id: this.arr[i]["id"], name: this.arr[i]["name"],
              description: this.arr[i]["description"], pour: this.arr[i]["pour"]});
      }
      return arra;
  }*/

  public getArray() {
      let arr = JSON.parse(JSON.stringify(this.JsonFile));
      return arr;
  }

  private setValue(arrayOfObjects: Array<Plant>) {
      firebase.setValue(
          this.path,
          arrayOfObjects
      );
  }
}
