"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var Sqlite = require("nativescript-sqlite");
var firebase = require("nativescript-plugin-firebase");
require("nativescript-localstorage");
var PlantsService = /** @class */ (function () {
    function PlantsService() {
        /*(new Sqlite("plants.db")).then(db => {
            db.execSQL("CREATE TABLE IF NOT EXISTS `plants` (" +
      "`id`	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
      "`name`	TEXT, " +
      "`description`	TEXT, " +
      "`pour`	INTEGER);").then(id => {
                this.database = db;
                console.log("Could be success");
            }, error => {
                console.log("CREATE TABLE ERROR", error);
            });
        }, error => {
            console.log("OPEN DB ERROR", error);
        });*/
        this._list = new Array({ id: 1, name: "Rose", description: "nice rose", pour: 1 }, { id: 2, name: "Cactus", description: "dust", pour: 7 });
        //this.addNew(3, "Tulip", "nice tulip", 2);
        //this._list.push({id: 3, name: "Tulip", description: "nice tulip", pour: 2});
        //this.setIt();
        /*this.fetch();
        this._list.push({ id: 1, name: "kek", description: "loles", pour: 4 })*/
    }
    PlantsService.prototype.save = function () {
        var listString = JSON.stringify(this._list);
        localStorage.setItem('Plants', listString);
    };
    PlantsService.prototype.get = function () {
        var listString = localStorage.getItem('Plants');
        this._list = JSON.parse(listString);
    };
    PlantsService.prototype.addNew = function (id, name, description, pour) {
        this.get();
        this._list.push({ id: id, name: name, description: description, pour: pour });
        this.save();
    };
    PlantsService.prototype.update = function (id, name, desc, pour) {
        this.get();
        var objToUpdate = this._list.find(function (obj) { return obj.id == id; });
        objToUpdate.name = name == "" ? objToUpdate.name : name;
        objToUpdate.description = desc == "" ? objToUpdate.description : desc;
        objToUpdate.pour = pour < 0 ? objToUpdate.pour : pour;
        var bs = this._list.filter(function (obj) { return obj.id != id; });
        this._list = bs.concat([objToUpdate]);
        this.save();
    };
    PlantsService.prototype.delete = function (id) {
        this.get();
        var bs = this._list.filter(function (obj) { return obj.id != id; });
        this._list = bs.slice();
        this.save();
    };
    PlantsService.prototype.setIt = function () {
        firebase.setValue('/companies', {
            foo: 'bar',
            updateTs: firebase.ServerValue.TIMESTAMP
        });
        firebase.push('/users', {
            'first': 'Eddy',
            'last': 'Verbruggen',
            'birthYear': 1977,
            'isMale': true,
            'address': {
                'street': 'foostreet',
                'number': 123
            }
        }).then(function (result) {
            console.log("created key: " + result.key);
        });
    };
    Object.defineProperty(PlantsService.prototype, "list", {
        /* public fetch() {
             this.database.all("SELECT * FROM `plants`").then(rows => {
                 this._list = new ObservableArray([]);
                 for(let row in rows) {
                     this._list.push({
                         id: rows[row][0],
                         name: rows[row][1],
                         description: rows[row][2],
                         pour: rows[row][3]
                     });
                 }
             }, error => {
                 console.log("SELECT ERROR", error);
             });
         }*/
        get: function () {
            return this._list;
        },
        set: function (value) {
            this._list = value;
        },
        enumerable: true,
        configurable: true
    });
    PlantsService = __decorate([
        core_1.Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], PlantsService);
    return PlantsService;
}());
exports.PlantsService = PlantsService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGxhbnRzLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwbGFudHMuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEyQztBQUkzQyxJQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUM5QyxJQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsOEJBQThCLENBQUMsQ0FBQztBQUN6RCxPQUFPLENBQUUsMkJBQTJCLENBQUUsQ0FBQztBQUt2QztJQUlFO1FBQ0k7Ozs7Ozs7Ozs7Ozs7YUFhSztRQUNMLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxLQUFLLENBQ2xCLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUMxRCxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FDekQsQ0FBQztRQUVGLDJDQUEyQztRQUMzQyw4RUFBOEU7UUFDOUUsZUFBZTtRQUNmO2dGQUN3RTtJQUM1RSxDQUFDO0lBRU0sNEJBQUksR0FBWDtRQUNJLElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVDLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFTSwyQkFBRyxHQUFWO1FBQ0ksSUFBSSxVQUFVLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNoRCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVNLDhCQUFNLEdBQWIsVUFBYyxFQUFVLEVBQUUsSUFBWSxFQUFFLFdBQW1CLEVBQUUsSUFBWTtRQUNyRSxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDWCxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDO1FBQzVFLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNoQixDQUFDO0lBRU0sOEJBQU0sR0FBYixVQUFjLEVBQVUsRUFBRSxJQUFZLEVBQUUsSUFBWSxFQUFFLElBQVk7UUFDOUQsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ1gsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBQyxHQUFHLElBQUssT0FBQSxHQUFHLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBWixDQUFZLENBQUMsQ0FBQztRQUN6RCxXQUFXLENBQUMsSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUN4RCxXQUFXLENBQUMsV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUN0RSxXQUFXLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUN0RCxJQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFDLEdBQUcsSUFBSyxPQUFBLEdBQUcsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFaLENBQVksQ0FBQyxDQUFDO1FBQ3BELElBQUksQ0FBQyxLQUFLLEdBQU8sRUFBRSxTQUFFLFdBQVcsRUFBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNoQixDQUFDO0lBRU0sOEJBQU0sR0FBYixVQUFjLEVBQVU7UUFDcEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ1gsSUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsVUFBQyxHQUFHLElBQUssT0FBQSxHQUFHLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBWixDQUFZLENBQUMsQ0FBQztRQUNwRCxJQUFJLENBQUMsS0FBSyxHQUFPLEVBQUUsUUFBQyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNoQixDQUFDO0lBRUQsNkJBQUssR0FBTDtRQUNJLFFBQVEsQ0FBQyxRQUFRLENBQ2IsWUFBWSxFQUNaO1lBQ0ksR0FBRyxFQUFFLEtBQUs7WUFDVixRQUFRLEVBQUUsUUFBUSxDQUFDLFdBQVcsQ0FBQyxTQUFTO1NBQzNDLENBQ0osQ0FBQztRQUVGLFFBQVEsQ0FBQyxJQUFJLENBQ1QsUUFBUSxFQUNSO1lBQ0ksT0FBTyxFQUFFLE1BQU07WUFDZixNQUFNLEVBQUUsWUFBWTtZQUNwQixXQUFXLEVBQUUsSUFBSTtZQUNqQixRQUFRLEVBQUUsSUFBSTtZQUNkLFNBQVMsRUFBRTtnQkFDUCxRQUFRLEVBQUUsV0FBVztnQkFDckIsUUFBUSxFQUFFLEdBQUc7YUFDaEI7U0FDSixDQUNKLENBQUMsSUFBSSxDQUNGLFVBQVUsTUFBTTtZQUNaLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM5QyxDQUFDLENBQ0osQ0FBQztJQUNOLENBQUM7SUFrQkMsc0JBQUksK0JBQUk7UUFoQlQ7Ozs7Ozs7Ozs7Ozs7O1lBY0k7YUFFSDtZQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3RCLENBQUM7YUFFRCxVQUFTLEtBQWM7WUFDbkIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDdkIsQ0FBQzs7O09BSkE7SUEvR1EsYUFBYTtRQUh6QixpQkFBVSxDQUFDO1lBQ1YsVUFBVSxFQUFFLE1BQU07U0FDbkIsQ0FBQzs7T0FDVyxhQUFhLENBb0h6QjtJQUFELG9CQUFDO0NBQUEsQUFwSEQsSUFvSEM7QUFwSFksc0NBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge1BsYW50fSBmcm9tIFwifi9wbGFudFwiO1xuaW1wb3J0IHtPYnNlcnZhYmxlQXJyYXl9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL2RhdGEvb2JzZXJ2YWJsZS1hcnJheVwiO1xuXG5jb25zdCBTcWxpdGUgPSByZXF1aXJlKFwibmF0aXZlc2NyaXB0LXNxbGl0ZVwiKTtcbmNvbnN0IGZpcmViYXNlID0gcmVxdWlyZShcIm5hdGl2ZXNjcmlwdC1wbHVnaW4tZmlyZWJhc2VcIik7XG5yZXF1aXJlKCBcIm5hdGl2ZXNjcmlwdC1sb2NhbHN0b3JhZ2VcIiApO1xuXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290J1xufSlcbmV4cG9ydCBjbGFzcyBQbGFudHNTZXJ2aWNlIHtcbiAgICBwcml2YXRlIGRhdGFiYXNlOiBhbnk7XG4gICAgcHJpdmF0ZSBfbGlzdDtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgIC8qKG5ldyBTcWxpdGUoXCJwbGFudHMuZGJcIikpLnRoZW4oZGIgPT4ge1xuICAgICAgICAgIGRiLmV4ZWNTUUwoXCJDUkVBVEUgVEFCTEUgSUYgTk9UIEVYSVNUUyBgcGxhbnRzYCAoXCIgK1xuXHRcImBpZGBcdElOVEVHRVIgTk9UIE5VTEwgUFJJTUFSWSBLRVkgQVVUT0lOQ1JFTUVOVCwgXCIgK1xuXHRcImBuYW1lYFx0VEVYVCwgXCIgK1xuXHRcImBkZXNjcmlwdGlvbmBcdFRFWFQsIFwiICtcblx0XCJgcG91cmBcdElOVEVHRVIpO1wiKS50aGVuKGlkID0+IHtcbiAgICAgICAgICAgICAgdGhpcy5kYXRhYmFzZSA9IGRiO1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNvdWxkIGJlIHN1Y2Nlc3NcIik7XG4gICAgICAgICAgfSwgZXJyb3IgPT4ge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNSRUFURSBUQUJMRSBFUlJPUlwiLCBlcnJvcik7XG4gICAgICAgICAgfSk7XG4gICAgICB9LCBlcnJvciA9PiB7XG4gICAgICAgICAgY29uc29sZS5sb2coXCJPUEVOIERCIEVSUk9SXCIsIGVycm9yKTtcbiAgICAgIH0pOyovXG4gICAgICB0aGlzLl9saXN0ID0gbmV3IEFycmF5PFBsYW50PihcbiAgICAgICAgICB7IGlkOiAxLCBuYW1lOiBcIlJvc2VcIiwgZGVzY3JpcHRpb246IFwibmljZSByb3NlXCIsIHBvdXI6IDEgfSxcbiAgICAgICAgICB7IGlkOiAyLCBuYW1lOlwiQ2FjdHVzXCIsIGRlc2NyaXB0aW9uOiBcImR1c3RcIiwgcG91cjogNyB9XG4gICAgICApO1xuXG4gICAgICAvL3RoaXMuYWRkTmV3KDMsIFwiVHVsaXBcIiwgXCJuaWNlIHR1bGlwXCIsIDIpO1xuICAgICAgLy90aGlzLl9saXN0LnB1c2goe2lkOiAzLCBuYW1lOiBcIlR1bGlwXCIsIGRlc2NyaXB0aW9uOiBcIm5pY2UgdHVsaXBcIiwgcG91cjogMn0pO1xuICAgICAgLy90aGlzLnNldEl0KCk7XG4gICAgICAvKnRoaXMuZmV0Y2goKTtcbiAgICAgIHRoaXMuX2xpc3QucHVzaCh7IGlkOiAxLCBuYW1lOiBcImtla1wiLCBkZXNjcmlwdGlvbjogXCJsb2xlc1wiLCBwb3VyOiA0IH0pKi9cbiAgfVxuXG4gIHB1YmxpYyBzYXZlKCl7XG4gICAgICBsZXQgbGlzdFN0cmluZyA9IEpTT04uc3RyaW5naWZ5KHRoaXMuX2xpc3QpO1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ1BsYW50cycsIGxpc3RTdHJpbmcpO1xuICB9XG5cbiAgcHVibGljIGdldCgpe1xuICAgICAgbGV0IGxpc3RTdHJpbmcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnUGxhbnRzJyk7XG4gICAgICB0aGlzLl9saXN0ID0gSlNPTi5wYXJzZShsaXN0U3RyaW5nKTtcbiAgfVxuXG4gIHB1YmxpYyBhZGROZXcoaWQ6IG51bWJlciwgbmFtZTogc3RyaW5nLCBkZXNjcmlwdGlvbjogc3RyaW5nLCBwb3VyOiBudW1iZXIpe1xuICAgICAgdGhpcy5nZXQoKTtcbiAgICAgIHRoaXMuX2xpc3QucHVzaCh7aWQ6IGlkLCBuYW1lOiBuYW1lLCBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24sIHBvdXI6IHBvdXJ9KTtcbiAgICAgIHRoaXMuc2F2ZSgpO1xuICB9XG5cbiAgcHVibGljIHVwZGF0ZShpZDogbnVtYmVyLCBuYW1lOiBzdHJpbmcsIGRlc2M6IHN0cmluZywgcG91cjogbnVtYmVyKXtcbiAgICAgIHRoaXMuZ2V0KCk7XG4gICAgICBsZXQgb2JqVG9VcGRhdGUgPSB0aGlzLl9saXN0LmZpbmQoKG9iaikgPT4gb2JqLmlkID09IGlkKTtcbiAgICAgIG9ialRvVXBkYXRlLm5hbWUgPSBuYW1lID09IFwiXCIgPyBvYmpUb1VwZGF0ZS5uYW1lIDogbmFtZTtcbiAgICAgIG9ialRvVXBkYXRlLmRlc2NyaXB0aW9uID0gZGVzYyA9PSBcIlwiID8gb2JqVG9VcGRhdGUuZGVzY3JpcHRpb24gOiBkZXNjO1xuICAgICAgb2JqVG9VcGRhdGUucG91ciA9IHBvdXIgPCAwID8gb2JqVG9VcGRhdGUucG91ciA6IHBvdXI7XG4gICAgICBjb25zdCBicyA9IHRoaXMuX2xpc3QuZmlsdGVyKChvYmopID0+IG9iai5pZCAhPSBpZCk7XG4gICAgICB0aGlzLl9saXN0ID0gWy4uLmJzLCBvYmpUb1VwZGF0ZV07XG4gICAgICB0aGlzLnNhdmUoKTtcbiAgfVxuXG4gIHB1YmxpYyBkZWxldGUoaWQ6IG51bWJlcil7XG4gICAgICB0aGlzLmdldCgpO1xuICAgICAgY29uc3QgYnMgPSB0aGlzLl9saXN0LmZpbHRlcigob2JqKSA9PiBvYmouaWQgIT0gaWQpO1xuICAgICAgdGhpcy5fbGlzdCA9IFsuLi5ic107XG4gICAgICB0aGlzLnNhdmUoKTtcbiAgfVxuXG4gIHNldEl0KCl7XG4gICAgICBmaXJlYmFzZS5zZXRWYWx1ZShcbiAgICAgICAgICAnL2NvbXBhbmllcycsXG4gICAgICAgICAge1xuICAgICAgICAgICAgICBmb286ICdiYXInLFxuICAgICAgICAgICAgICB1cGRhdGVUczogZmlyZWJhc2UuU2VydmVyVmFsdWUuVElNRVNUQU1QXG4gICAgICAgICAgfVxuICAgICAgKTtcblxuICAgICAgZmlyZWJhc2UucHVzaChcbiAgICAgICAgICAnL3VzZXJzJyxcbiAgICAgICAgICB7XG4gICAgICAgICAgICAgICdmaXJzdCc6ICdFZGR5JyxcbiAgICAgICAgICAgICAgJ2xhc3QnOiAnVmVyYnJ1Z2dlbicsXG4gICAgICAgICAgICAgICdiaXJ0aFllYXInOiAxOTc3LFxuICAgICAgICAgICAgICAnaXNNYWxlJzogdHJ1ZSxcbiAgICAgICAgICAgICAgJ2FkZHJlc3MnOiB7XG4gICAgICAgICAgICAgICAgICAnc3RyZWV0JzogJ2Zvb3N0cmVldCcsXG4gICAgICAgICAgICAgICAgICAnbnVtYmVyJzogMTIzXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICApLnRoZW4oXG4gICAgICAgICAgZnVuY3Rpb24gKHJlc3VsdCkge1xuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImNyZWF0ZWQga2V5OiBcIiArIHJlc3VsdC5rZXkpO1xuICAgICAgICAgIH1cbiAgICAgICk7XG4gIH1cblxuICAgLyogcHVibGljIGZldGNoKCkge1xuICAgICAgICB0aGlzLmRhdGFiYXNlLmFsbChcIlNFTEVDVCAqIEZST00gYHBsYW50c2BcIikudGhlbihyb3dzID0+IHtcbiAgICAgICAgICAgIHRoaXMuX2xpc3QgPSBuZXcgT2JzZXJ2YWJsZUFycmF5KFtdKTtcbiAgICAgICAgICAgIGZvcihsZXQgcm93IGluIHJvd3MpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9saXN0LnB1c2goe1xuICAgICAgICAgICAgICAgICAgICBpZDogcm93c1tyb3ddWzBdLFxuICAgICAgICAgICAgICAgICAgICBuYW1lOiByb3dzW3Jvd11bMV0sXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiByb3dzW3Jvd11bMl0sXG4gICAgICAgICAgICAgICAgICAgIHBvdXI6IHJvd3Nbcm93XVszXVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LCBlcnJvciA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIlNFTEVDVCBFUlJPUlwiLCBlcnJvcik7XG4gICAgICAgIH0pO1xuICAgIH0qL1xuXG4gICAgZ2V0IGxpc3QoKTogUGxhbnRbXSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9saXN0O1xuICAgIH1cblxuICAgIHNldCBsaXN0KHZhbHVlOiBQbGFudFtdKSB7XG4gICAgICAgIHRoaXMuX2xpc3QgPSB2YWx1ZTtcbiAgICB9XG59XG4iXX0=