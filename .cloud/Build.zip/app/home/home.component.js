"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var plants_service_1 = require("~/services/plants.service");
var firebase_service_1 = require("~/services/firebase.service");
//import {action, alert, confirm, prompt, login} from "tns-core-modules/ui/dialogs";
var HomeComponent = /** @class */ (function () {
    function HomeComponent(plantsService, firebaseService) {
        this.plantsService = plantsService;
        this.firebaseService = firebaseService;
        this.title = 'PlantsGo';
        this.counter = 42;
    }
    HomeComponent.prototype.ngOnInit = function () {
        this.plants = this.plantsService.list;
        console.log(this.plants.toString());
        //this.plants = this.plantsService.list;
        console.log("is it working?");
    };
    /*public action(comment: Plant) {
        action({
            message: comment.title,
            cancelButtonText: "Cancel",
            actions: [!comment.done ? "Done" : "Still doing", "Edit", "Delete"]
        }).then((result) => {
            if (result == "Done") {
                this.plantsService.changeOnDone(comment);
            }  else if (result == "Still doing") {
                this.plantsService.changeOnDone(comment);
            } else if (result == "Edit"){
                this.edit(comment);
            } else if (result == "Delete"){
                this.confirmDelete(comment);
            }
        });
    }*/
    /* private confirmDelete(comment: Plant) {
         confirm({
             title: comment.name,
             message: "Are you sure that you want to delete this TODO challenge?",
             okButtonText: "YES",
             cancelButtonText: "NO"
         }).then((result) => {
             if(result == true){
                 this.plantsService.delete(comment.id);
             }
         });
     }*/
    /*private edit(comment: Plant) {
        prompt({
            title: comment.name,
            message: "Edit your plant name",
            okButtonText: "OK",
            cancelButtonText: "Cancel",
            defaultText: comment.name,
            inputType: inputType.text,
            cancelable: true
        }).then((result) => {
            if(result.result == true) {
                this.plantsService.update(comment.id, result.name);
            }
        });
    }*/
    HomeComponent.prototype.getMessage = function () {
        return this.counter > 0 ?
            this.counter + " taps left" :
            'Hoorraaay! You unlocked the NativeScript clicker achievement!';
    };
    HomeComponent.prototype.onTap = function () {
        this.counter--;
    };
    HomeComponent = __decorate([
        core_1.Component({
            selector: 'app-home',
            templateUrl: './home.component.html',
            styleUrls: ['./home.component.css'],
            moduleId: module.id,
        }),
        __metadata("design:paramtypes", [plants_service_1.PlantsService,
            firebase_service_1.FirebaseService])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaG9tZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJob21lLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFnRDtBQUVoRCw0REFBd0Q7QUFDeEQsZ0VBQTREO0FBQzVELG9GQUFvRjtBQVFwRjtJQU1FLHVCQUFvQixhQUE0QixFQUM1QixlQUFnQztRQURoQyxrQkFBYSxHQUFiLGFBQWEsQ0FBZTtRQUM1QixvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7UUFOcEQsVUFBSyxHQUFHLFVBQVUsQ0FBQztRQUNYLFlBQU8sR0FBRyxFQUFFLENBQUM7SUFPckIsQ0FBQztJQUVELGdDQUFRLEdBQVI7UUFDRSxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO1FBQ3RDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ3BDLHdDQUF3QztRQUN4QyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVDOzs7Ozs7Ozs7Ozs7Ozs7O09BZ0JHO0lBRUo7Ozs7Ozs7Ozs7O1FBV0k7SUFFSDs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUVFLGtDQUFVLEdBQWpCO1FBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDcEIsSUFBSSxDQUFDLE9BQU8sZUFBWSxDQUFDLENBQUM7WUFDN0IsK0RBQStELENBQUM7SUFDcEUsQ0FBQztJQUVNLDZCQUFLLEdBQVo7UUFDRSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDakIsQ0FBQztJQXpFVSxhQUFhO1FBTnpCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsVUFBVTtZQUNwQixXQUFXLEVBQUUsdUJBQXVCO1lBQ3BDLFNBQVMsRUFBRSxDQUFDLHNCQUFzQixDQUFDO1lBQ25DLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtTQUNwQixDQUFDO3lDQU9tQyw4QkFBYTtZQUNYLGtDQUFlO09BUHpDLGFBQWEsQ0EwRXpCO0lBQUQsb0JBQUM7Q0FBQSxBQTFFRCxJQTBFQztBQTFFWSxzQ0FBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7Q29tcG9uZW50LCBPbkluaXR9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtQbGFudH0gZnJvbSBcIn4vcGxhbnRcIjtcbmltcG9ydCB7UGxhbnRzU2VydmljZX0gZnJvbSBcIn4vc2VydmljZXMvcGxhbnRzLnNlcnZpY2VcIjtcbmltcG9ydCB7RmlyZWJhc2VTZXJ2aWNlfSBmcm9tIFwifi9zZXJ2aWNlcy9maXJlYmFzZS5zZXJ2aWNlXCI7XG4vL2ltcG9ydCB7YWN0aW9uLCBhbGVydCwgY29uZmlybSwgcHJvbXB0LCBsb2dpbn0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvZGlhbG9nc1wiO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtaG9tZScsXG4gIHRlbXBsYXRlVXJsOiAnLi9ob21lLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vaG9tZS5jb21wb25lbnQuY3NzJ10sXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG59KVxuZXhwb3J0IGNsYXNzIEhvbWVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXR7XG4gIHRpdGxlID0gJ1BsYW50c0dvJztcbiAgcHJpdmF0ZSBjb3VudGVyID0gNDI7XG4gIHByaXZhdGUgcGxhbnRzOiBQbGFudFtdO1xuICBwcml2YXRlIGtlaztcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHBsYW50c1NlcnZpY2U6IFBsYW50c1NlcnZpY2UsXG4gICAgICAgICAgICAgIHByaXZhdGUgZmlyZWJhc2VTZXJ2aWNlOiBGaXJlYmFzZVNlcnZpY2UpIHtcblxuICB9XG5cbiAgbmdPbkluaXQoKXtcbiAgICB0aGlzLnBsYW50cyA9IHRoaXMucGxhbnRzU2VydmljZS5saXN0O1xuICAgIGNvbnNvbGUubG9nKHRoaXMucGxhbnRzLnRvU3RyaW5nKCkpO1xuICAgIC8vdGhpcy5wbGFudHMgPSB0aGlzLnBsYW50c1NlcnZpY2UubGlzdDtcbiAgICBjb25zb2xlLmxvZyhcImlzIGl0IHdvcmtpbmc/XCIpO1xuICB9XG5cbiAgICAvKnB1YmxpYyBhY3Rpb24oY29tbWVudDogUGxhbnQpIHtcbiAgICAgICAgYWN0aW9uKHtcbiAgICAgICAgICAgIG1lc3NhZ2U6IGNvbW1lbnQudGl0bGUsXG4gICAgICAgICAgICBjYW5jZWxCdXR0b25UZXh0OiBcIkNhbmNlbFwiLFxuICAgICAgICAgICAgYWN0aW9uczogWyFjb21tZW50LmRvbmUgPyBcIkRvbmVcIiA6IFwiU3RpbGwgZG9pbmdcIiwgXCJFZGl0XCIsIFwiRGVsZXRlXCJdXG4gICAgICAgIH0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgaWYgKHJlc3VsdCA9PSBcIkRvbmVcIikge1xuICAgICAgICAgICAgICAgIHRoaXMucGxhbnRzU2VydmljZS5jaGFuZ2VPbkRvbmUoY29tbWVudCk7XG4gICAgICAgICAgICB9ICBlbHNlIGlmIChyZXN1bHQgPT0gXCJTdGlsbCBkb2luZ1wiKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wbGFudHNTZXJ2aWNlLmNoYW5nZU9uRG9uZShjb21tZW50KTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAocmVzdWx0ID09IFwiRWRpdFwiKXtcbiAgICAgICAgICAgICAgICB0aGlzLmVkaXQoY29tbWVudCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHJlc3VsdCA9PSBcIkRlbGV0ZVwiKXtcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpcm1EZWxldGUoY29tbWVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0qL1xuXG4gICAvKiBwcml2YXRlIGNvbmZpcm1EZWxldGUoY29tbWVudDogUGxhbnQpIHtcbiAgICAgICAgY29uZmlybSh7XG4gICAgICAgICAgICB0aXRsZTogY29tbWVudC5uYW1lLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJBcmUgeW91IHN1cmUgdGhhdCB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyBUT0RPIGNoYWxsZW5nZT9cIixcbiAgICAgICAgICAgIG9rQnV0dG9uVGV4dDogXCJZRVNcIixcbiAgICAgICAgICAgIGNhbmNlbEJ1dHRvblRleHQ6IFwiTk9cIlxuICAgICAgICB9KS50aGVuKChyZXN1bHQpID0+IHtcbiAgICAgICAgICAgIGlmKHJlc3VsdCA9PSB0cnVlKXtcbiAgICAgICAgICAgICAgICB0aGlzLnBsYW50c1NlcnZpY2UuZGVsZXRlKGNvbW1lbnQuaWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9Ki9cblxuICAgIC8qcHJpdmF0ZSBlZGl0KGNvbW1lbnQ6IFBsYW50KSB7XG4gICAgICAgIHByb21wdCh7XG4gICAgICAgICAgICB0aXRsZTogY29tbWVudC5uYW1lLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJFZGl0IHlvdXIgcGxhbnQgbmFtZVwiLFxuICAgICAgICAgICAgb2tCdXR0b25UZXh0OiBcIk9LXCIsXG4gICAgICAgICAgICBjYW5jZWxCdXR0b25UZXh0OiBcIkNhbmNlbFwiLFxuICAgICAgICAgICAgZGVmYXVsdFRleHQ6IGNvbW1lbnQubmFtZSxcbiAgICAgICAgICAgIGlucHV0VHlwZTogaW5wdXRUeXBlLnRleHQsXG4gICAgICAgICAgICBjYW5jZWxhYmxlOiB0cnVlXG4gICAgICAgIH0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgaWYocmVzdWx0LnJlc3VsdCA9PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wbGFudHNTZXJ2aWNlLnVwZGF0ZShjb21tZW50LmlkLCByZXN1bHQubmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0qL1xuXG4gIHB1YmxpYyBnZXRNZXNzYWdlKCkge1xuICAgIHJldHVybiB0aGlzLmNvdW50ZXIgPiAwID9cbiAgICAgIGAke3RoaXMuY291bnRlcn0gdGFwcyBsZWZ0YCA6XG4gICAgICAnSG9vcnJhYWF5ISBZb3UgdW5sb2NrZWQgdGhlIE5hdGl2ZVNjcmlwdCBjbGlja2VyIGFjaGlldmVtZW50ISc7XG4gIH1cblxuICBwdWJsaWMgb25UYXAoKSB7XG4gICAgdGhpcy5jb3VudGVyLS07XG4gIH1cbn1cbiJdfQ==