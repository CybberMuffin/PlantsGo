import {Component, OnInit} from '@angular/core';
import {Plant} from "~/plant";
import {PlantsService} from "~/services/plants.service";
import {FirebaseService} from "~/services/firebase.service";
//import {action, alert, confirm, prompt, login} from "tns-core-modules/ui/dialogs";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  moduleId: module.id,
})
export class HomeComponent implements OnInit{
  title = 'PlantsGo';
  private counter = 42;
  private plants: Plant[];
  private kek;

  constructor(private plantsService: PlantsService,
              private firebaseService: FirebaseService) {

  }

  ngOnInit(){
    this.plants = this.plantsService.list;
    console.log(this.plants.toString());
    //this.plants = this.plantsService.list;
    console.log("is it working?");
  }

    /*public action(comment: Plant) {
        action({
            message: comment.title,
            cancelButtonText: "Cancel",
            actions: [!comment.done ? "Done" : "Still doing", "Edit", "Delete"]
        }).then((result) => {
            if (result == "Done") {
                this.plantsService.changeOnDone(comment);
            }  else if (result == "Still doing") {
                this.plantsService.changeOnDone(comment);
            } else if (result == "Edit"){
                this.edit(comment);
            } else if (result == "Delete"){
                this.confirmDelete(comment);
            }
        });
    }*/

   /* private confirmDelete(comment: Plant) {
        confirm({
            title: comment.name,
            message: "Are you sure that you want to delete this TODO challenge?",
            okButtonText: "YES",
            cancelButtonText: "NO"
        }).then((result) => {
            if(result == true){
                this.plantsService.delete(comment.id);
            }
        });
    }*/

    /*private edit(comment: Plant) {
        prompt({
            title: comment.name,
            message: "Edit your plant name",
            okButtonText: "OK",
            cancelButtonText: "Cancel",
            defaultText: comment.name,
            inputType: inputType.text,
            cancelable: true
        }).then((result) => {
            if(result.result == true) {
                this.plantsService.update(comment.id, result.name);
            }
        });
    }*/

  public getMessage() {
    return this.counter > 0 ?
      `${this.counter} taps left` :
      'Hoorraaay! You unlocked the NativeScript clicker achievement!';
  }

  public onTap() {
    this.counter--;
  }
}
