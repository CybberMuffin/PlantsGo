import { Component } from '@angular/core';
import firebase = require("nativescript-plugin-firebase");

@Component({
  selector: 'app-root',
  template: `<page-router-outlet></page-router-outlet>`
})
export class AppComponent {
  constructor(){
    firebase.init();
  }
}
